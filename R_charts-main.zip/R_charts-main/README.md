# Broad data references
 - https://tcpd.ashoka.edu.in/data/
 - https://www.eiu.com/
 - https://rbi.org.in/Scripts/Statistics.aspx
 - https://data.worldbank.org/
 - https://worldpopulationreview.com/

# Reference Video
 https://www.youtube.com/watch?v=qQNXe-fP_Ek //to understand how to configure token + keychain access
# Branding ideas
We want our charts to be recognisable as coming from 'our Instagram handle', and to stand out in feeds
We could use red (#EC111A) as the main or highlight colour, with more subtle blues/greys as the secondary colours. There are exceptions such as political charts which use party colours, or some maps where colours might have specific associations
It’s okay to be flexible when needed, as long as there’s a strong template to fall back on

## Figure 1
List of worlds 15 most polluted cities in 2020
References:
- https://medium.economist.com/charting-new-territory-7f5afb293270
- https://www.iqair.com/world-most-polluted-cities-

## Figure 2
How India fares in the democracy index ; 2006 - 2021
References: EIU
